package com.amsh.app

data class DataItem(
    val title: String,
    val subtitle: String
)
