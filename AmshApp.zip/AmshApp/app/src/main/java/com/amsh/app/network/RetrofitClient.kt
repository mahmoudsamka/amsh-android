package com.amsh.app.network

import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.concurrent.TimeUnit

/**
 * غيّر السطر ده لرابط السيرفر بتاعك بعد النشر (Render/Railway/إلخ).
 * لازم ينتهي بـ "/" — مثال: "https://amsh-backend.onrender.com/"
 */
object ApiConfig {
    const val BASE_URL = "https://REPLACE-WITH-YOUR-SERVER-URL.onrender.com/"
}

object RetrofitClient {

    private val logging = HttpLoggingInterceptor().apply {
        level = HttpLoggingInterceptor.Level.BASIC
    }

    private val okHttpClient = OkHttpClient.Builder()
        .addInterceptor(logging)
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(15, TimeUnit.SECONDS)
        .build()

    private val retrofit: Retrofit by lazy {
        Retrofit.Builder()
            .baseUrl(ApiConfig.BASE_URL)
            .client(okHttpClient)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }

    val authApi: AuthApi by lazy { retrofit.create(AuthApi::class.java) }
    val dataApi: DataApi by lazy { retrofit.create(DataApi::class.java) }
}
