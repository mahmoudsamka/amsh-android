package com.amsh.app

import android.content.Intent
import android.os.Bundle
import android.util.Patterns
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.amsh.app.databinding.ActivityLoginBinding
import com.amsh.app.network.LoginRequest
import com.amsh.app.network.RetrofitClient
import kotlinx.coroutines.launch
import java.io.IOException

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.btnLogin.setOnClickListener { attemptLogin() }
    }

    private fun attemptLogin() {
        val email = binding.etEmail.text.toString().trim()
        val password = binding.etPassword.text.toString().trim()

        val validationError = when {
            email.isEmpty() || !Patterns.EMAIL_ADDRESS.matcher(email).matches() ->
                getString(R.string.error_email)
            password.length < 4 ->
                getString(R.string.error_password)
            else -> null
        }

        if (validationError != null) {
            showError(validationError)
            return
        }

        showError(null)
        setLoading(true)

        lifecycleScope.launch {
            try {
                val response = RetrofitClient.authApi.login(LoginRequest(email, password))
                setLoading(false)

                if (response.isSuccessful && response.body()?.token != null) {
                    goToList()
                } else {
                    showError(getString(R.string.error_login_failed))
                }
            } catch (e: IOException) {
                setLoading(false)
                showError(getString(R.string.error_network))
            } catch (e: Exception) {
                setLoading(false)
                showError(getString(R.string.error_login_failed))
            }
        }
    }

    private fun setLoading(loading: Boolean) {
        binding.progressBar.visibility = if (loading) View.VISIBLE else View.GONE
        binding.btnLogin.isEnabled = !loading
    }

    private fun showError(message: String?) {
        if (message == null) {
            binding.tvError.visibility = View.GONE
        } else {
            binding.tvError.text = message
            binding.tvError.visibility = View.VISIBLE
        }
    }

    private fun goToList() {
        startActivity(Intent(this, MainActivity::class.java))
        finish()
    }
}
