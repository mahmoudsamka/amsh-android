package com.amsh.app

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import com.amsh.app.databinding.ActivityMainBinding
import com.amsh.app.network.RetrofitClient
import kotlinx.coroutines.launch
import java.io.IOException

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding

    private val requestNotifPermission = registerForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            NotificationHelper.show(this, getString(R.string.notif_title), getString(R.string.notif_body))
        } else {
            Toast.makeText(this, "لازم تسمح بالإشعارات الأول", Toast.LENGTH_SHORT).show()
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        NotificationHelper.createChannel(this)

        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        binding.swipeRefresh.setOnRefreshListener { loadData() }

        loadData()
    }

    private fun loadData() {
        binding.tvError.visibility = View.GONE
        if (!binding.swipeRefresh.isRefreshing) {
            binding.progressBar.visibility = View.VISIBLE
        }

        lifecycleScope.launch {
            try {
                val response = RetrofitClient.dataApi.getPosts()
                binding.progressBar.visibility = View.GONE
                binding.swipeRefresh.isRefreshing = false

                if (response.isSuccessful && response.body() != null) {
                    val items = response.body()!!.take(20).map { post ->
                        DataItem(post.title.replaceFirstChar { it.uppercase() }, post.body)
                    }
                    binding.recyclerView.adapter = DataAdapter(items) { item ->
                        triggerNotification(item)
                    }
                } else {
                    showError()
                }
            } catch (e: IOException) {
                binding.progressBar.visibility = View.GONE
                binding.swipeRefresh.isRefreshing = false
                showError()
            } catch (e: Exception) {
                binding.progressBar.visibility = View.GONE
                binding.swipeRefresh.isRefreshing = false
                showError()
            }
        }
    }

    private fun showError() {
        binding.tvError.text = getString(R.string.error_loading_data)
        binding.tvError.visibility = View.VISIBLE
    }

    private fun triggerNotification(item: DataItem) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            val hasPermission = ContextCompat.checkSelfPermission(
                this, Manifest.permission.POST_NOTIFICATIONS
            ) == PackageManager.PERMISSION_GRANTED

            if (hasPermission) {
                NotificationHelper.show(this, item.title, item.subtitle)
            } else {
                requestNotifPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
            }
        } else {
            NotificationHelper.show(this, item.title, item.subtitle)
        }
    }
}
