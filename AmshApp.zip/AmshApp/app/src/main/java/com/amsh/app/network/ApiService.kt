package com.amsh.app.network

import retrofit2.Response
import retrofit2.http.Body
import retrofit2.http.GET
import retrofit2.http.POST

/* ---------- طلبات وردود اللوجين (reqres.in — API تجريبي عام) ---------- */

data class LoginRequest(
    val email: String,
    val password: String
)

data class LoginResponse(
    val token: String? = null,
    val error: String? = null
)

/* ---------- عنصر بيانات من jsonplaceholder ---------- */

data class PostResponse(
    val id: Int,
    val title: String,
    val body: String
)

interface AuthApi {
    @POST("api/login")
    suspend fun login(@Body request: LoginRequest): Response<LoginResponse>
}

interface DataApi {
    @GET("posts")
    suspend fun getPosts(): Response<List<PostResponse>>
}
