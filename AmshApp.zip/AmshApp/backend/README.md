# سيرفر AMSH — جاهز للنشر

ده باك إند حقيقي (Node.js + Express) فيه:
- `POST /api/login` — بيتحقق من إيميل وباسورد ويرجّع token
- `GET /posts` — بيرجّع قائمة بيانات حقيقية

بيانات الدخول التجريبية:
```
Email: mahmoud@amsh.com
Password: amsh1234
```

## ملحوظة مهمة

أنا (Claude) مش عندي القدرة إني "أنشر" أو "أشغّل" سيرفر لايف بنفسي — مفيش عندي اتصال إنترنت خارجي أو استضافة. اللي أقدر أعمله هو إني أجهزلك الكود كامل وجاهز 100%، وانت تنشره في 5 دقايق من موبايلك بس، من غير ما تحتاج كمبيوتر أو تكتب أمر واحد.

## إزاي تنشره من الموبايل (خطوة بخطوة)

### 1. اعمل حساب GitHub (لو مالكش واحد)
- افتح github.com من متصفح الموبايل → Sign up

### 2. ارفع الملفين دول (`server.js` و `package.json`) في repo جديد
- من صفحة GitHub الرئيسية دوس "+" فوق → "New repository"
- سمّيه `amsh-backend` → Create repository
- في صفحة الـ repo، دوس "Add file" → "Upload files"
- ارفع `server.js` و `package.json` من نفس المجلد ده
- دوس "Commit changes"

### 3. اعمل حساب على Render.com (استضافة مجانية)
- افتح render.com من المتصفح → Sign up باستخدام حساب GitHub بتاعك (هيربطهم لبعض تلقائي)

### 4. انشر السيرفر
- من لوحة Render دوس "New +" → "Web Service"
- اختار الـ repo بتاع `amsh-backend`
- اسم الخدمة: أي اسم تحبه (مثلاً `amsh-backend`)
- Build Command: سيبه فاضي (Render بيكتشفه لوحده لمشاريع Node)
- Start Command: `npm start`
- Instance Type: اختار **Free**
- دوس "Create Web Service"

استنى دقيقتين لحد ما يظهر status "Live" ✅، وهيديك رابط شكله كده:
```
https://amsh-backend-xxxx.onrender.com
```

### 5. حدّث التطبيق
افتح `AmshApp/app/src/main/java/com/amsh/app/network/RetrofitClient.kt` وغيّر السطر:
```kotlin
const val BASE_URL = "https://REPLACE-WITH-YOUR-SERVER-URL.onrender.com/"
```
لرابطك الحقيقي (لازم يخلص بـ `/`). كده التطبيق بقى شغال بالكامل من عندك، من أي مكان في الدنيا.

> ملحوظة: الاستضافة المجانية في Render بتنام لو محدش استخدمها لمدة، وأول طلب بعد النوم بياخد 20-30 ثانية يصحّيها. ده طبيعي في الخطة المجانية.
