# AMSH — تطبيق Kotlin + سيرفر جاهز

المشروع كامل بجزئين:

```
AmshApp/
├── app/          ← تطبيق أندرويد Kotlin (Android Studio)
└── backend/      ← سيرفر Node.js/Express حقيقي (login + posts)
```

## اللي في التطبيق

- **شاشة لوجين** بتبعت طلب حقيقي عن طريق Retrofit
- **قائمة بيانات** بتتحمّل من السيرفر، مع Pull-to-refresh وحالات تحميل/خطأ
- **إشعارات** بتطلب صلاحية أندرويد 13+ وبتبعت إشعار حقيقي
- تصميم داكن بألوان AMSH (`#0D1012` خلفية، `#22D3B0` لون مميز)

## اللي في السيرفر

باك إند حقيقي (`backend/server.js`) فيه endpoint لوجين وendpoint بيانات، جاهز تنشره بمجرد رفعه على استضافة مجانية زي Render — **كل الخطوات موجودة في `backend/README.md`**، وكلها بتتعمل من المتصفح على الموبايل من غير كمبيوتر.

بيانات الدخول التجريبية للسيرفر: `mahmoud@amsh.com` / `amsh1234`

## الخطوات المطلوبة منك (مرة واحدة بس)

1. اتبع خطوات `backend/README.md` عشان تنشر السيرفر (5 دقايق من الموبايل)
2. خد الرابط اللي هيديهولك Render
3. حطه في `app/src/main/java/com/amsh/app/network/RetrofitClient.kt` مكان:
   ```kotlin
   const val BASE_URL = "https://REPLACE-WITH-YOUR-SERVER-URL.onrender.com/"
   ```
4. افتح `AmshApp` (مجلد الـ app بس) في Android Studio ودوس Run ▶️

كده التطبيق شغال بالكامل من عندك، من أي مكان.

## هيكل تطبيق الأندرويد

```
app/src/main/java/com/amsh/app/
├── LoginActivity.kt
├── MainActivity.kt
├── DataAdapter.kt
├── DataItem.kt
├── NotificationHelper.kt
└── network/
    ├── ApiService.kt
    └── RetrofitClient.kt
```

## تطوير إضافي مقترح

- ربط السيرفر بقاعدة بيانات حقيقية (MongoDB/PostgreSQL) بدل الذاكرة
- تشفير الباسورد (bcrypt) بدل التخزين الصريح
- حفظ التوكن وحالة تسجيل الدخول بـ SharedPreferences أو DataStore
